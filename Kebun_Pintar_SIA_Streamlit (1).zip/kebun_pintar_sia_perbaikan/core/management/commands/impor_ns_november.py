"""Django management command: impor NS 31 Oktober 2026 menjadi saldo awal November.

Letakkan di core/management/commands/impor_ns_november.py
File sumber: Database_Referensi_NS_31Okt2026_November.sqlite3 di samping manage.py

Audit (tanpa mengubah): python manage.py impor_ns_november
Apply (setelah baca peringatan tumpang tindih periode):
    python manage.py impor_ns_november --apply --setuju-periode-terpisah

PENTING: command ini disusun dari struktur core yang dijelaskan dalam percakapan;
model dan database SQLite lokal pengguna belum tersedia untuk pengujian integrasi.
"""
import sqlite3
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path

from django.core.management.base import BaseCommand, CommandError
from django.db import connection, transaction
from django.conf import settings

from core.models import (
    Account, AccountingPeriod, JournalEntry, JournalLine,
    InventoryItem, InventoryMovement,
)

SOURCE_NAME = "Database_Referensi_NS_31Okt2026_November.sqlite3"
JOURNAL_NUMBER = "SA-NOV-2026-001"
OPENING_REFERENCE = "STOK-AWAL-NOV-2026-BAYAM-001"
PERIOD_NAME = "November 2026"


class Command(BaseCommand):
    help = "Audit/impor COA revisi dan saldo awal November secara terpisah; tidak menghapus jurnal lama."

    def add_arguments(self, parser):
        parser.add_argument("--source", default=SOURCE_NAME, help="Path database referensi SQLite.")
        parser.add_argument("--apply", action="store_true", help="Benar-benar menerapkan (default hanya audit).")
        parser.add_argument(
            "--setuju-periode-terpisah", action="store_true",
            help="Akui bahwa periode November akan terpisah dari Tahun 2026 lama dan laporan harus memilih periode November.",
        )

    def handle(self, *args, **options):
        source = Path(options["source"]).expanduser().resolve()
        if not source.is_file():
            raise CommandError(f"Database referensi tidak ditemukan: {source}")

        try:
            with sqlite3.connect(str(source)) as con:
                con.row_factory = sqlite3.Row
                rows = [dict(r) for r in con.execute(
                    "SELECT * FROM coa_accounts ORDER BY display_order"
                )]
                stock = dict(con.execute("SELECT * FROM opening_stock").fetchone())
        except (sqlite3.Error, TypeError) as exc:
            raise CommandError(f"Tidak bisa membaca database referensi: {exc}") from exc

        total_debit = sum(r["debit_31_oct"] for r in rows)
        total_credit = sum(r["credit_31_oct"] for r in rows)
        if (len(rows), total_debit, total_credit) != (29, 36_442_000, 36_442_000):
            raise CommandError("Data referensi tidak cocok dengan NS tervalidasi (29 akun; 36.442.000 = 36.442.000).")
        if not (stock["item_code"] == "BAYAM-001" and stock["unit"] == "ikat"
                and Decimal(stock["quantity"]) == Decimal("100.000")
                and stock["amount"] == 180000
                and Decimal(stock["unit_cost"]) * Decimal(stock["quantity"]) == Decimal("180000.00")):
            raise CommandError("Data stok awal tidak sesuai: 100 ikat @ Rp1.800.")

        required = {
            Account: {"account_code", "account_name", "category", "normal_balance"},
            AccountingPeriod: {"period_name", "start_date", "end_date", "status"},
            JournalEntry: {"entry_number", "accounting_period", "entry_date", "description", "status", "entry_type"},
            JournalLine: {"journal_entry", "account", "debit", "credit"},
            InventoryItem: {"item_code", "item_name", "item_type", "unit", "is_active"},
            InventoryMovement: {"item", "movement_date", "movement_type", "quantity", "unit_cost", "reference"},
        }
        for model, needed in required.items():
            available = {f.name for f in model._meta.fields}
            if not needed <= available:
                raise CommandError(
                    f"Model {model.__name__} tidak cocok. Field kurang: {sorted(needed-available)}. "
                    "Jangan lanjut: periksa model lokal."
                )

        account_code_field = Account._meta.get_field("account_code")
        if account_code_field.primary_key:
            raise CommandError("account_code merupakan PK; penggantian kode lama harus dimigrasi khusus agar FK jurnal aman.")

        legacy_1050 = Account.objects.filter(account_code="1050").first()
        legacy_1060 = Account.objects.filter(account_code="1060").first()
        legacy_1070 = Account.objects.filter(account_code="1070").first()
        migrate_legacy = False
        if legacy_1050 and legacy_1050.account_name.strip().lower().startswith("perlengkapan"):
            if not (legacy_1060 and "sewa dibayar" in legacy_1060.account_name.lower()
                    and legacy_1070 is None):
                raise CommandError("Kode 1050/1060/1070 sudah berbeda dari COA lama; perlu rekonsiliasi manual.")
            migrate_legacy = True
        elif legacy_1050:
            if "persediaan bayam hasil panen" not in legacy_1050.account_name.lower():
                raise CommandError("Akun 1050 memiliki nama tidak dikenal; dilarang menimpanya.")
        elif legacy_1060 and "sewa dibayar" in legacy_1060.account_name.lower():
            raise CommandError("Akun lama 1060 masih Sewa; tidak aman membuat 1050 baru tanpa migrasi kode.")

        existing_period = AccountingPeriod.objects.filter(period_name=PERIOD_NAME).first()
        if existing_period and (
            existing_period.start_date != date(2026, 11, 1)
            or existing_period.end_date != date(2026, 11, 30)
        ):
            raise CommandError("Periode November 2026 ada dengan batas tanggal berbeda.")

        existing_journal = JournalEntry.objects.filter(entry_number=JOURNAL_NUMBER).first()
        if existing_journal:
            raise CommandError(
                f"Jurnal {JOURNAL_NUMBER} sudah ada. Untuk menghindari saldo ganda, "
                "impor otomatis berhenti. Audit dan cocokkan jurnal tersebut secara manual."
            )

        # Cegah mengimpor saldo awal lagi di tengah transaksi November yang sudah ada.
        old_period_nov_journals = JournalEntry.objects.filter(
            entry_date__gte=date(2026, 11, 1),
            entry_date__lte=date(2026, 11, 30),
        ).exclude(accounting_period__period_name=PERIOD_NAME)
        if old_period_nov_journals.exists():
            raise CommandError(
                "Sudah ada jurnal bertanggal November pada periode lain. "
                "Migrasikan atau rekonsiliasi dulu agar tidak berganda."
            )

        existing_item = InventoryItem.objects.filter(item_code=stock["item_code"]).first()
        if existing_item and (
            existing_item.unit.lower() != "ikat"
            or existing_item.item_type != InventoryItem.ItemType.HARVEST
        ):
            raise CommandError("BAYAM-001 sudah ada tetapi bukan Hasil Panen satuan ikat.")
        if existing_item and existing_item.movements.filter(
            movement_date__lte=date(2026, 11, 1)
        ).exists():
            raise CommandError("BAYAM-001 memiliki mutasi sebelumnya/di tanggal awal. Jangan menambah 100 ikat dua kali.")
        if InventoryMovement.objects.filter(reference=OPENING_REFERENCE).exists():
            raise CommandError("Mutasi stok awal November sudah pernah dicatat; tidak boleh diduplikasi.")

        previous_posted = JournalEntry.objects.filter(
            status=JournalEntry.Status.POSTED,
        ).count()
        self.stdout.write(f"COA sumber: {len(rows)} akun; debit Rp{total_debit:,}; kredit Rp{total_credit:,}")
        self.stdout.write("Persediaan awal: 100 ikat, akun 1050 Rp180.000, biaya tersirat Rp1.800/ikat")
        self.stdout.write(f"Jurnal Posted yang sudah ada: {previous_posted} (tidak akan dihapus)")
        self.stdout.write(f"Perpindahan kode lama 1050 -> 1060 dan 1060 -> 1070: {'perlu' if migrate_legacy else 'tidak perlu'}")
        self.stdout.write("Saldo 31 Oktober akan menjadi jurnal pembukaan 1 November dalam periode tersendiri.")
        self.stdout.write("PERINGATAN: Periode Tahun 2026 lama bisa tumpang tindih; laporan harus filter November 2026.")

        if not options["apply"]:
            self.stdout.write(self.style.WARNING(
                "MODE AUDIT: database Django BELUM diubah. Periksa periode dan laporan sebelum --apply."
            ))
            return
        if not options["setuju_periode_terpisah"]:
            raise CommandError(
                "Tambahkan --setuju-periode-terpisah hanya setelah memahami bahwa periode November "
                "harus dipilih khusus pada laporan; jangan menjumlah saldo awal Januari dan November."
            )

        # Backup database SQLite aktual pengguna sebelum tindakan.
        dbname = connection.settings_dict.get("NAME")
        if connection.vendor != "sqlite" or not dbname or str(dbname) == ":memory:":
            raise CommandError("Impor --apply hanya mendukung database utama SQLite berbasis file.")
        dbpath = Path(dbname).resolve()
        if not dbpath.exists():
            raise CommandError(f"Database Django tidak ditemukan: {dbpath}")
        backup = dbpath.with_name(
            f"{dbpath.stem}_backup_sebelum_Nov_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".sqlite3"
        )
        connection.ensure_connection()
        with sqlite3.connect(str(backup)) as backup_conn:
            connection.connection.backup(backup_conn)
        self.stdout.write(self.style.SUCCESS(f"Backup database dibuat: {backup}"))

        # Seluruh migrasi data dibatalkan bersama jika salah satu bagian gagal.
        with transaction.atomic():
            if migrate_legacy:
                # PK tabel Account tidak berubah; FK JournalLine lama tetap menunjuk akun ekonomi yang sama.
                # Pindahkan Sewa terlebih dahulu untuk menghindari benturan unique account_code.
                Account.objects.filter(pk=legacy_1060.pk).update(account_code="1070")
                Account.objects.filter(pk=legacy_1050.pk).update(account_code="1060")

            for row in rows:
                defaults = {
                    "account_name": row["account_name"],
                    "category": row["account_type"],
                    "normal_balance": row["normal_balance"],
                }
                obj, created = Account.objects.update_or_create(
                    account_code=row["account_code"], defaults=defaults
                )
                obj.full_clean()

            period = AccountingPeriod.objects.create(
                period_name=PERIOD_NAME,
                start_date=date(2026, 11, 1),
                end_date=date(2026, 11, 30),
                status="open",
            ) if not existing_period else existing_period
            period.full_clean()
            if period.status != "open":
                raise CommandError("Periode November tidak berstatus open.")

            journal = JournalEntry.objects.create(
                entry_number=JOURNAL_NUMBER,
                accounting_period=period,
                entry_date=date(2026, 11, 1),
                description="Saldo awal November berdasarkan Neraca Saldo 31 Oktober 2026 (COA revisi)",
                status=JournalEntry.Status.DRAFT,
                entry_type=JournalEntry.EntryType.OPENING,
            )
            accounts_by_code = {a.account_code: a for a in Account.objects.filter(
                account_code__in=[r["account_code"] for r in rows]
            )}
            for row in rows:
                if not row["debit_31_oct"] and not row["credit_31_oct"]:
                    continue
                JournalLine.objects.create(
                    journal_entry=journal,
                    account=accounts_by_code[row["account_code"]],
                    debit=Decimal(row["debit_31_oct"]),
                    credit=Decimal(row["credit_31_oct"]),
                )
            journal.status = JournalEntry.Status.POSTED
            journal.save()

            if existing_item is None:
                existing_item = InventoryItem.objects.create(
                    item_code="BAYAM-001",
                    item_name="Bayam Hasil Panen",
                    item_type=InventoryItem.ItemType.HARVEST,
                    unit="ikat",
                    is_active=True,
                )
            InventoryMovement.objects.create(
                item=existing_item,
                movement_date=date(2026, 11, 1),
                movement_type=InventoryMovement.MovementType.IN,
                quantity=Decimal("100.000"),
                unit_cost=Decimal("1800.00"),
                reference=OPENING_REFERENCE,
                description="Saldo fisik awal November 100 ikat; NILAINYA SUDAH masuk di jurnal saldo awal akun 1050.",
            )

        self.stdout.write(self.style.SUCCESS(
            "IMPOR SELESAI: 29 akun, jurnal saldo awal November Posted, stok awal 100 ikat. "
            "7 transaksi simulasi TIDAK dijurnal otomatis."
        ))
        self.stdout.write(
            "CATATAN: Periksa periode pada setiap laporan. Laporan tahunan 2026 lama dan laporan November tidak boleh digabung tanpa penyesuaian."
        )
