import json
from pathlib import Path
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from core.models import Account


class Command(BaseCommand):
    help = 'Impor COA secara atomik; akun yang sudah dipakai tidak boleh berubah makna.'

    def add_arguments(self,parser):
        parser.add_argument('--source',help='File JSON atau Excel. Default: config/coa.json yang telah diselaraskan.')

    @transaction.atomic
    def handle(self,*args,**options):
        path=Path(options.get('source') or settings.BASE_DIR/'config/coa.json')
        try:
            if path.suffix.lower()=='.xlsx':
                rows=self.read_excel(path)
            else:
                rows=json.loads(path.read_text(encoding='utf-8'))
        except (OSError,ValueError,KeyError,TypeError) as error:
            raise CommandError('Sumber COA tidak valid: '+str(error)) from error
        if not rows or len({r['account_code'] for r in rows})!=len(rows):
            raise CommandError('COA kosong atau kode akun berulang.')
        for row in rows:
            old=Account.objects.filter(account_code=row['account_code']).first()
            if old and old.journal_lines.exists() and any(getattr(old,k)!=row[k] for k in ['account_name','category','normal_balance']):
                raise CommandError(f"Impor ditolak: akun {old.account_code} sudah dipakai dan sumber mengubah maknanya.")
            candidate=Account(pk=old.pk if old else None,account_code=row['account_code'],account_name=row['account_name'],category=row['category'],normal_balance=row['normal_balance'],is_active=old.is_active if old else True)
            candidate.full_clean()
        for row in rows:
            account,created=Account.objects.get_or_create(account_code=row['account_code'],defaults={k:row[k] for k in ['account_name','category','normal_balance']})
            if not created and not account.journal_lines.exists():
                for key in ['account_name','category','normal_balance']:
                    setattr(account,key,row[key])
                account.save()
        self.stdout.write(self.style.SUCCESS(f'COA diperiksa: {len(rows)} akun. Tidak ada makna akun terpakai yang ditimpa.'))

    def read_excel(self,path):
        from openpyxl import load_workbook
        workbook=load_workbook(path,read_only=True,data_only=True)
        category=None;rows=[]
        categories={'Aset Lancar':'asset','Aset Tetap':'asset','Kewajiban Lancar':'liability','Ekuitas':'equity','Pendapatan':'revenue','Pembelian':'expense','Beban Operasional':'expense'}
        try:
            for values in workbook.active.iter_rows(min_row=2,values_only=True):
                code,name=values[:2]
                if not code and name:
                    category=categories.get(str(name).strip(),category)
                elif code and name:
                    code=str(code).strip()
                    if not category:
                        raise CommandError('Kategori akun Excel tidak ditemukan.')
                    normal='credit' if category in ['liability','equity','revenue'] else 'debit'
                    if code in ['1211','1221','5030','5040']:normal='credit'
                    if code in ['3020','4020','4030']:normal='debit'
                    rows.append(dict(account_code=code,account_name=str(name).strip(),category=category,normal_balance=normal))
        finally:
            workbook.close()
        return rows
