# Perbaikan Sistem Informasi Akuntansi Budidaya Bayam

Saya memperbaiki bug pada alur sistem yang sudah ada: pemesanan, penjualan, persediaan, panen, jurnal, dan laporan keuangan. Saya memakai hasil pengujian untuk memastikan perbaikannya berjalan.

## 1. Hak akses halaman dan aksi admin

**Apa masalahnya?** Saya menemukan buku besar dapat dibuka tanpa login. Pengguna yang hanya mempunyai izin melihat juga dapat menjalankan aksi posting jurnal, penyelesaian penjualan, dan panen.

**Kenapa bermasalah?** Pengguna tersebut dapat membaca informasi keuangan atau mengubah transaksi di luar kewenangannya.

**Bagaimana saya memperbaikinya?** Saya mewajibkan login dan izin melihat laporan keuangan untuk dashboard serta laporan. Saya menambahkan izin perubahan dan pemeriksaan izin di dalam ketiga aksi admin. Saya menguji bahwa pengguna hanya-lihat tidak dapat menjalankan aksi tersebut.

## 2. Penutupan periode

**Apa masalahnya?** Saya menemukan periode November masih terbuka walaupun jurnal penutup sudah diposting. Jurnal baru dan jurnal penutup kedua masih dapat masuk.

**Kenapa bermasalah?** Saldo yang sudah ditutup dapat berubah dan laporan setelah penutupan tidak lagi final.

**Bagaimana saya memperbaikinya?** Saya membuat posting jurnal penutup sekaligus mengubah status periode menjadi tertutup dalam satu transaksi database. Saya menolak pencatatan pada periode tertutup dan membatasi satu jurnal penutup Posted per periode. Sebelum posting penutup, saya memeriksa jurnal Draft, pembelian yang belum dialokasikan, kecocokan FIFO dengan jurnal persediaan/HPP, serta sisa pendapatan, beban, dan prive setelah penutupan.

## 3. Perlindungan jurnal dan pesanan selesai

**Apa masalahnya?** Saya menemukan jurnal Posted masih bisa dihapus melalui operasi tertentu. Kuantitas dan nilai pesanan selesai juga masih dapat diubah tanpa mengubah jurnal dan stoknya.

**Kenapa bermasalah?** Nilai pada pesanan dapat berbeda dari bukti transaksi dan laporan keuangan.

**Bagaimana saya memperbaikinya?** Saya mengunci nilai dan status pesanan selesai, menampilkan datanya sebagai hanya-baca, dan menolak penghapusannya. Saya juga melindungi jurnal Posted, baris jurnal, serta mutasi persediaan dari perubahan dan penghapusan melalui model maupun operasi massal ORM. Saya menambahkan constraint agar satu baris jurnal hanya mempunyai satu sisi positif dan total pesanan sesuai harga dikali jumlah.

## 4. Impor daftar akun

**Apa masalahnya?** Saya menemukan sumber COA lama menggunakan makna kode akun yang berbeda. Kode 1050, misalnya, dapat berubah dari persediaan hasil panen menjadi perlengkapan.

**Kenapa bermasalah?** Mengganti makna akun yang sudah digunakan akan membuat jurnal lama terbaca sebagai transaksi yang berbeda.

**Bagaimana saya memperbaikinya?** Saya menyelaraskan sumber COA bawaan dengan daftar akun pada database. Saya membuat impor memeriksa seluruh data terlebih dahulu dan menjalankannya secara atomik. Saya menolak impor yang mengubah nama, kategori, atau saldo normal akun yang sudah dipakai. Pemeriksaan yang sama juga berlaku saat akun diedit melalui admin.

## 5. Perhitungan laporan keuangan

**Apa masalahnya?** Saya menemukan saldo awal hanya terbaca jika nomor jurnal diawali `SA-`. Akun beban tambahan juga dapat terlewat dari laporan.

**Kenapa bermasalah?** Transaksi yang sebenarnya sah dapat tidak masuk laporan, bahkan neraca dapat terlihat seimbang karena saldo awal sama-sama tidak terbaca.

**Bagaimana saya memperbaikinya?** Saya memakai jenis jurnal `opening` untuk mengenali saldo awal. Saya mengambil pendapatan, beban, aset, liabilitas, dan ekuitas berdasarkan kategorinya agar akun tambahan tetap diperhitungkan. Saya menjaga laba/rugi tetap mengalir ke perubahan ekuitas dan neraca. Saya juga menampilkan peringatan apabila HPP atau nilai persediaan belum cocok dengan FIFO, serta apabila laporan setelah penutupan masih bersifat sementara.

## 6. Biaya produksi dan pencatatan panen

**Apa masalahnya?** Saya menemukan nilai panen dapat diisi tanpa cocok dengan biaya batch. Satu sumber jurnal biaya juga dapat dialokasikan melebihi nilainya.

**Kenapa bermasalah?** Nilai persediaan panen dapat berbeda dari biaya produksi yang dapat dibuktikan.

**Bagaimana saya memperbaikinya?** Saya membatasi total alokasi biaya sesuai debit sumber jurnal WIP yang sudah Posted. Sebelum panen, saya memeriksa bahwa seluruh biaya mempunyai sumber tersebut dan jumlah panen dikali biaya per unit sama dengan total biaya batch. Pada aksi panen yang sudah ada, saya menambahkan jurnal transfer debit persediaan hasil panen dan kredit persediaan dalam proses. Mutasi, jurnal, dan perubahan batch disimpan bersama sehingga semuanya dibatalkan jika satu langkah gagal.

## 7. Validasi persediaan

**Apa masalahnya?** Saya menemukan stok masuk pada tanggal berikutnya dapat digunakan untuk membenarkan stok keluar pada tanggal sebelumnya. Biaya stok masuk nol juga diterima, tetapi perhitungan FIFO kemudian gagal.

**Kenapa bermasalah?** Stok dapat negatif pada tanggal transaksi dan persediaan tidak dapat dinilai secara konsisten.

**Bagaimana saya memperbaikinya?** Saya menolak mutasi bertanggal mundur apabila sudah ada mutasi setelah tanggal tersebut. Saya mewajibkan kuantitas positif dan biaya stok masuk lebih dari nol. Saya melindungi mutasi tersimpan dari perubahan langsung. Saya juga menyembunyikan input stok lama dari formulir produk agar pengguna memakai stok aktual hasil perhitungan mutasi.

## 8. Validasi dan pengiriman ulang checkout

**Apa masalahnya?** Saya menemukan nama terlalu panjang, nomor WhatsApp tidak valid, serta pengiriman formulir berulang masih diterima.

**Kenapa bermasalah?** Data pesanan menjadi tidak rapi dan satu pengiriman dapat tercatat sebagai beberapa pesanan.

**Bagaimana saya memperbaikinya?** Saya menggunakan Django Form untuk memeriksa panjang nama, format nomor, jumlah, harga, dan stok. Saya menambahkan token formulir bertanda tangan serta kunci unik untuk mencegah pencatatan ulang dari formulir yang sama. Setelah berhasil, saya mengarahkan pengguna ke halaman konfirmasi sehingga penyegaran halaman tidak mengulang POST. Jika gagal, saya mempertahankan isian dan menampilkan kesalahan pada field yang sesuai.

## 9. Konsistensi data lama dan dashboard

**Apa masalahnya?** Saya menemukan tiga pesanan lama berstatus selesai tanpa jurnal atau mutasi, sehingga dashboard menampilkan Rp699.000 sementara jurnal penjualan menunjukkan Rp690.000. Periode tahunan lama juga bercampur dengan pilihan periode November.

**Kenapa bermasalah?** Angka pemesanan yang belum mempunyai bukti realisasi dapat dianggap sebagai pendapatan akuntansi.

**Bagaimana saya memperbaikinya?** Saya menghitung nilai penjualan dan grafik dari jurnal Posted berdasarkan tanggal realisasinya. Saya menandai pesanan 14, 15, dan 16 sebagai perlu rekonsiliasi, mempertahankan catatannya, dan tidak membuat jurnal pengganti tanpa bukti. Saya memisahkan periode tahunan lama sebagai arsip agar pilihan laporan aktif tidak mencampurkan dua dataset. Pada salinan database perbaikan, status November saya sesuaikan menjadi tertutup karena jurnal penutupnya memang sudah tersedia.

## 10. Kesalahan input dan efisiensi laporan

**Apa masalahnya?** Saya menemukan parameter filter yang tidak valid dapat menghasilkan error 500. Penjualan dengan status yang salah juga dapat memunculkan `NameError` ketika aplikasi menangani kegagalan.

**Kenapa bermasalah?** Kesalahan input biasa dapat menghentikan penggunaan aplikasi saat demonstrasi.

**Bagaimana saya memperbaikinya?** Saya memvalidasi ID filter dan mengembalikan respons 404 yang terkendali untuk pilihan tidak valid. Saya memperbaiki impor exception pada aksi penjualan agar kegagalan menjadi pesan validasi. Saya juga mengganti query per akun pada neraca saldo dan query stok per baris admin dengan agregasi, sehingga halaman tidak perlu mengambil data berulang untuk setiap baris.

## 11. Konfigurasi menjalankan aplikasi

**Apa masalahnya?** Saya menemukan secret tertulis langsung di kode, konfigurasi pengembangan bercampur dengan konfigurasi deployment, dan dependensi belum didokumentasikan.

**Kenapa bermasalah?** Aplikasi sulit dijalankan ulang dengan lingkungan yang jelas dan konfigurasi yang sesuai.

**Bagaimana saya memperbaikinya?** Saya memisahkan konfigurasi lokal dan deployment, memindahkan secret deployment ke variabel lingkungan, dan membuat secret lokal tersimpan otomatis saat aplikasi pertama dijalankan. Saya menambahkan daftar dependensi, petunjuk menjalankan, dan aturan pengecualian file lingkungan. Saya juga membatasi foto produk melalui formulir admin hingga 2 MB dan sisi maksimal 4096 piksel.

## 12. Tampilan pada layar kecil

**Apa masalahnya?** Saya menemukan grafik dashboard melebar keluar dari layar ponsel, sementara pesan kesalahan formulir belum membantu pengguna menemukan field yang salah.

**Kenapa bermasalah?** Pengguna perlu menggeser seluruh halaman dan sulit mengetahui bagian formulir yang harus diperbaiki.

**Bagaimana saya memperbaikinya?** Saya membatasi luapan grafik di dalam area gulirnya, menjaga tabel tetap dapat digeser, dan menambahkan penanda fokus keyboard. Pada formulir gagal, saya menampilkan ringkasan kesalahan yang mengarah ke field terkait. Saya memeriksa ulang halaman pada lebar 1280 dan 390 piksel.

## Hasil pengujian saya

- Saya menjalankan **67 tes**: 42 skenario bawaan dengan fixture yang disesuaikan terhadap validasi, serta 25 tes regresi temuan audit. Semuanya lulus.
- Saya menjalankan pemeriksaan Django, konsistensi migrasi, dan pemeriksaan konfigurasi deployment. Tidak ada masalah yang dilaporkan pada pemeriksaan akhir.
- Saya mencoba login dan checkout melalui browser. Saya memeriksa dashboard serta laporan utama pada layar desktop dan ponsel tanpa error JavaScript atau luapan halaman.
- Saya memastikan angka November tetap: **penjualan Rp690.000, HPP Rp320.400, rugi bersih Rp963.733,34**, dan **aset Rp31.478.266,66 sama dengan liabilitas ditambah ekuitas**.
- Saya mengerjakan dan menguji salinan proyek. Arsip awal dan seluruh file sumber audit tetap tersimpan sebagai pembanding.
