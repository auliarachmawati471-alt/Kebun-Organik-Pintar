# Menjalankan Kebun Pintar SIA

Saya menggunakan Python 3.12 atau versi yang kompatibel dengan Django 5.2. Saya menjalankan perintah berikut dari folder yang berisi `manage.py`.

## Persiapan di Windows

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe manage.py migrate
.\.venv\Scripts\python.exe manage.py createsuperuser
.\.venv\Scripts\python.exe manage.py runserver 127.0.0.1:8000
```

Saya membuka [aplikasi lokal](http://127.0.0.1:8000/) dan masuk melalui [halaman admin](http://127.0.0.1:8000/admin/). Saya membuat akun admin sendiri melalui `createsuperuser`; tidak ada password admin yang ditulis pada dokumentasi.

## Data yang saya pakai untuk presentasi

Saya memilih **November 2026** untuk menunjukkan laporan yang sudah direkonsiliasi. Periode ini sudah ditutup. Untuk mencoba transaksi baru, saya membuat periode berikutnya yang terbuka dan mengisi saldo awal melalui jurnal `opening`, sesuai alur jurnal yang sudah tersedia.

Saya mempertahankan metode HPP periodik: penjualan mencatat kas/piutang dan pendapatan, kemudian jurnal penyesuaian HPP dibuat pada akhir periode. Sistem menampilkan perbedaan terhadap FIFO dan menolak penutupan jika penyesuaian belum sesuai.

Saya menandai tiga pesanan lama tanpa jurnal/mutasi sebagai perlu rekonsiliasi. Saya dapat melihat penandanya pada daftar pesanan. Catatan tersebut tetap disimpan dan tidak dimasukkan sebagai realisasi penjualan.

Untuk akun staf yang perlu membaca laporan, saya memberikan izin **Dapat melihat laporan keuangan**. Aksi posting jurnal, penyelesaian penjualan, dan panen membutuhkan izin perubahan pada model terkait.

## Pengujian yang saya jalankan

```powershell
.\.venv\Scripts\python.exe manage.py check
.\.venv\Scripts\python.exe manage.py test core --settings=config.test
.\.venv\Scripts\python.exe manage.py makemigrations --check --dry-run
```

Saya mencatat penjelasan perbaikan dalam `DOKUMENTASI_PERBAIKAN.md`. Ringkasan hasil akhir tersedia dalam `hasil_pengujian.json`.

## Konfigurasi lokal

Perintah `manage.py` memakai `config.local`. Secret lokal dibuat otomatis dalam `.local_secret` dan tidak disertakan dalam paket. Jika saya mengaktifkan tautan konfirmasi WhatsApp, saya mengisi variabel `WHATSAPP_CONTACT` dengan digit nomor berkode negara sebelum menjalankan server.

Konfigurasi deployment berada di `config.settings` dan memerlukan `DJANGO_SECRET_KEY` serta `DJANGO_ALLOWED_HOSTS`. Saya memakai konfigurasi lokal untuk presentasi di komputer sendiri.
