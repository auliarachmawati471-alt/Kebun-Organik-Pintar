# Kebun Pintar SIA — Streamlit

## Migrasi antarmuka
Aplikasi ini menggunakan Streamlit sebagai antarmuka utama. Model, database SQLite,
validasi, service akuntansi, metode HPP periodik, rekonsiliasi FIFO, serta aturan
transaksi dari project Django dipertahankan sebagai backend agar data dan aturan
bisnis yang sudah ada tidak hilang. Django tidak lagi dijalankan sebagai web server;
Django ORM dipakai oleh Streamlit untuk mengakses database dan menjalankan layanan.

## Menjalankan di Windows / VS Code
1. Ekstrak folder project.
2. Buka folder `kebun_pintar_sia_perbaikan` di VS Code.
3. Buka terminal dan buat environment:
   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   ```
4. Jalankan aplikasi:
   ```powershell
   streamlit run app.py
   ```
5. Browser akan membuka alamat Streamlit lokal (umumnya `http://localhost:8501`).

## Data dan login
- `db.sqlite3` tetap dipakai; tidak perlu membuat database baru atau menjalankan migrate
  untuk project yang sudah memiliki database siap pakai.
- Login menggunakan akun staf Django yang sudah ada di database. Password tidak
  disimpan di kode. Akun harus aktif dan memiliki status staff.
- Izin laporan keuangan tetap memeriksa permission `core.view_financial_reports`.
- File gambar produk tetap dibaca dari folder media.
- Atur `WHATSAPP_CONTACT` sesuai format nomor internasional tanpa tanda plus jika
  ingin menampilkan tautan WhatsApp penjual.

## Fitur Streamlit
Beranda/pemesanan, dashboard admin, produk, pesanan dan penyelesaian penjualan,
daftar akun, periode akuntansi, jurnal umum (draft dan posting), buku besar,
neraca saldo, neraca saldo setelah penyesuaian, ringkasan neraca lajur, laba rugi,
perubahan ekuitas, neraca, jurnal penutup/neraca saldo setelah penutupan, persediaan,
mutasi/kartu stok, kelompok tanam, biaya produksi, dan pencatatan panen.

## Catatan batasan konversi
Antarmuka Django Admin dan halaman HTML Django digantikan oleh menu Streamlit.
Operasi khusus yang sebelumnya hanya tersedia melalui admin Django perlu dijalankan
melalui alur Streamlit yang tersedia atau dikembangkan lebih lanjut. Sebagian laporan
saat ini ditampilkan sebagai tabel/ringkasan; tata letak cetak dan beberapa formulir
admin tingkat lanjut belum identik 1:1 dengan Django. Jangan menghapus database asli;
buat salinan cadangan sebelum pengujian transaksi.
