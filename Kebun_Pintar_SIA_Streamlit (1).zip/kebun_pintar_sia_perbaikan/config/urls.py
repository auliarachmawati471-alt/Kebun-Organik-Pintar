
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path

from core.views import (
    home,
    checkout, checkout_success,
    admin_dashboard,
    general_ledger,
    trial_balance,
    adjusted_trial_balance,
    worksheet,
    laporan_laba_rugi,
    laporan_perubahan_ekuitas,
    laporan_neraca,
    neraca_saldo_setelah_penutupan,
    laporan_jurnal_penutup,
)


urlpatterns = [
    path(
        "admin/buku-besar/",
        general_ledger,
        name="general_ledger",
    ),

    path(
        "admin/dashboard/",
        admin_dashboard,
        name="admin_dashboard",
    ),

    path(
        "admin/neraca-saldo/",
        trial_balance,
        name="trial_balance",
    ),

    path(
        "admin/neraca-saldo-setelah-penyesuaian/",
        adjusted_trial_balance,
        name="adjusted_trial_balance",
    ),

    path(
        "admin/neraca-lajur/",
        worksheet,
        name="worksheet",
    ),
    path(
        "admin/laba-rugi/",
        laporan_laba_rugi,
        name="laporan_laba_rugi",
    ),
        path(
        "admin/perubahan-ekuitas/",
        laporan_perubahan_ekuitas,
        name="laporan_perubahan_ekuitas",
    ),
        path(
        "admin/neraca/",
        laporan_neraca,
        name="laporan_neraca",
    ),
        path(
        "admin/neraca-saldo-setelah-penutupan/",
        neraca_saldo_setelah_penutupan,
        name="neraca_saldo_setelah_penutupan",
    ),
        path(
        "admin/jurnal-penutup/",
        laporan_jurnal_penutup,
        name="laporan_jurnal_penutup",
    ),
    path("admin/", admin.site.urls),

    path("", home, name="home"),
    path("checkout/berhasil/<str:token>/",checkout_success,name="checkout_success"),

    path(
        "checkout/<int:product_id>/",
        checkout,
        name="checkout",
    ),
]


if settings.DEBUG:
    urlpatterns += static(
        settings.MEDIA_URL,
        document_root=settings.MEDIA_ROOT,
    )
