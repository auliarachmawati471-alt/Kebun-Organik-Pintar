import os
os.environ.setdefault('DJANGO_SECRET_KEY','test-only-non-production-key-for-isolated-django-test-suite-2026')
from .settings import *
ALLOWED_HOSTS = ['testserver','localhost','127.0.0.1']
SECURE_SSL_REDIRECT = False
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False
PASSWORD_HASHERS = ['django.contrib.auth.hashers.MD5PasswordHasher']
