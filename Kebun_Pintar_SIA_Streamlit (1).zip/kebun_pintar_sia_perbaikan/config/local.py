"""Local demonstration only; production entry points use config.settings."""
import os
from pathlib import Path
from django.core.management.utils import get_random_secret_key

if not os.environ.get('DJANGO_SECRET_KEY'):
    key_path = Path(__file__).resolve().parent.parent / '.local_secret'
    try:
        with key_path.open('x',encoding='utf-8') as stream:
            stream.write(get_random_secret_key())
    except FileExistsError:
        pass
    os.environ['DJANGO_SECRET_KEY'] = key_path.read_text(encoding='utf-8').strip()

from .settings import *
DEBUG = True
SECURE_SSL_REDIRECT = False
SECURE_HSTS_SECONDS = 0
SECURE_HSTS_INCLUDE_SUBDOMAINS = False
SECURE_HSTS_PRELOAD = False
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False
